import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RemuserPage } from './remuser';

@NgModule({
  declarations: [
    RemuserPage,
  ],
  imports: [
    IonicPageModule.forChild(RemuserPage),
  ],
})
export class RemuserPageModule {}
