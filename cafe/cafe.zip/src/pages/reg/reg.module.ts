import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RegPage } from './reg';

@NgModule({
  declarations: [
    RegPage,
  ],
  imports: [
    IonicPageModule.forChild(RegPage),
  ],
})
export class RegPageModule {}
