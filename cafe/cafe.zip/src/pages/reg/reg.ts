import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { LoginProvider } from '../../providers/login/login';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import { map } from 'rxjs/operators';
import { AlertController, ToastController } from 'ionic-angular';
import { ErrorHandler, NgModule } from '@angular/core';
import { LoginPage } from '../login/login';
import { Login2Page } from '../login2/login2';


/**
 * Generated class for the RegPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-reg',
  templateUrl: 'reg.html'
})

export  class RegPage {
  

  todos: Observable<any>;
  username: String;
  password:String;
  email:String;
  phone:String;
  role:String;

  constructor(public http:Http,public navCtrl: NavController, public todoService: LoginProvider, public alertCtrl: AlertController, public toastCtrl: ToastController) {
    //this.loadTodos();
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad RegPage');
  }
  
  register() {
 
    let data = {
        username: this.username,
        password:this.password,
        email: this.email,
        phone: this.phone,
       role: this.role
    };
    console.log(data);

    this.http.post('http://localhost:3000/reg',data).pipe(
        map(res => res.json())
    ).subscribe(res => {
      console.log('POST Response:', res);
        this.navCtrl.push(Login2Page);
               
        this.showToast('',JSON.stringify(res));
    });
    /*this.http.get('http://localhost:3000/user').pipe(
        map(res => res.json())
    ).subscribe(response => {
        console.log('GET Response:', JSON.stringify(response));
        this.showToast('GET Response:', JSON.stringify(response));
    });*/

  }
  private showToast(message: string,res:Object) {
    let toast = this.toastCtrl.create({
      message: message + res,
      duration: 10000
    });
    toast.present();
  }
 
}
